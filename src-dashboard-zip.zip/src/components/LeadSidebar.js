// LeadSidebar.js
import React from "react";
import { FaHome, FaListAlt, FaSignOutAlt } from "react-icons/fa";
import "./LeadSidebar.css";

const LeadSidebar = ({ setActiveComponent }) => {
  return (
    <div className="lead-sidebar">
      <h2>Lead Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaHome className="icon" /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("view-timesheet")}>
          <FaListAlt className="icon" /> View Timesheet
        </li>
        <li
          onClick={() => {
            localStorage.removeItem("token");
            localStorage.removeItem("empId");
            window.location.href = "/login";
          }}
        >
          <FaSignOutAlt /> Logout
        </li>
      </ul>
    </div>
  );
};

export default LeadSidebar;
