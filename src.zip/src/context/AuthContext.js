import { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [empId, setEmpId] = useState(
    () => sessionStorage.getItem("empId") || null
  );

  const login = (id) => {
    setEmpId(id);
    sessionStorage.setItem("empId", id);
  };

  const logout = () => {
    setEmpId(null);
    sessionStorage.removeItem("empId");
    sessionStorage.removeItem("token");
  };

  return (
    <AuthContext.Provider value={{ empId, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
