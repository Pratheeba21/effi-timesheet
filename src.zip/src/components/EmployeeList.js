import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import api from "../api/api"; // Adjust the import if needed
import "./EmployeeList.css";

const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    api
      .get("employees/")
      .then((response) => setEmployees(response.data))
      .catch((error) => console.error("Error fetching employee list:", error));
  }, []);

  return (
    <div className="employee-list">
      <h2>Select an Employee to Update Timesheet</h2>
      <ul>
        {employees.map((employee) => (
          <li key={employee.emp_id}>
            <Link to={`/update-timesheet/${employee.emp_id}`}>
              {employee.emp_name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EmployeeList;
