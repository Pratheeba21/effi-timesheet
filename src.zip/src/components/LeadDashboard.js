import React from "react";
import LeadSidebar from "./LeadSidebar";
import Home from "./Home";
import LeadPage from "./LeadPage";
import EmployeeList from "./EmployeeList";
import UpdateTimesheet from "./UpdateTimesheet";
import { useParams } from "react-router-dom";
import "./LeadDashboard.css";

const LeadDashboard = () => {
  const { emp_id } = useParams();
  const [activeComponent, setActiveComponent] = React.useState("home");

  const renderContent = () => {
    switch (activeComponent) {
      case "home":
        return <Home />;
      case "view-timesheet":
        return <LeadPage />;
      case "update-timesheet":
        return emp_id ? <UpdateTimesheet emp_id={emp_id} /> : <EmployeeList />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="lead-dashboard">
      <LeadSidebar setActiveComponent={setActiveComponent} />
      <div className="lead-content">{renderContent()}</div>
    </div>
  );
};

export default LeadDashboard;
