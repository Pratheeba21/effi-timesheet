from django.contrib import admin
from .models import Employee, Timesheet, Project
from django.contrib.auth.hashers import make_password

class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('emp_id', 'emp_name', 'email_id', 'joining_date', 'timestamp', 'person_status')
    search_fields = ('emp_id', 'emp_name', 'email_id')

    def save_model(self, request, obj, form, change):
        if 'password' in form.changed_data:
            obj.password = make_password(obj.password)
        super().save_model(request, obj, form, change)

class TimesheetAdmin(admin.ModelAdmin):
    list_display = ('emp', 'date', 'project_name','project_module', 'start_time', 'end_time', 'total_hours', 'timestamp', 'lead_approval', 'manager_approval')
    list_filter = ('date', 'project_name', 'emp')
    search_fields = ('project_name', 'emp__emp_name', 'emp__emp_id')

class ProjectAdmin(admin.ModelAdmin):
    list_display = ('emp', 'project_name', 'status', 'timestamp')
    list_filter = ('status', 'emp')
    search_fields = ('project_name', 'emp__emp_name', 'emp__emp_id')

admin.site.register(Employee, EmployeeAdmin)
admin.site.register(Timesheet, TimesheetAdmin)
admin.site.register(Project, ProjectAdmin)
