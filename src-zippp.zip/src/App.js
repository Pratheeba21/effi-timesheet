import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
  useLocation,
} from "react-router-dom";
import Dashboard from "./components/Dashboard";
import UpdateTimesheet from "./components/UpdateTimesheet";
import ViewTimesheet from "./components/ViewTimesheet";
import Login from "./components/Login";
import LeadDashboard from "./components/LeadDashboard";
import ManagerDashboard from "./components/ManagerDashboard";
import Sidebar from "./components/Sidebar"; // Import Sidebar
import { AuthProvider, useAuth } from "./context/AuthContext";
import "./App.css";

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="app">
          <Content />
        </div>
      </Router>
    </AuthProvider>
  );
};

const Content = () => {
  const { empId } = useAuth();
  const location = useLocation();

  // Only show the sidebar for employee-specific routes
  const showSidebar =
    empId &&
    ["/dashboard", "/update-timesheet", "/view-timesheet"].includes(
      location.pathname
    );

  return (
    <>
      {showSidebar && <Sidebar />}
      <div className={showSidebar ? "content" : ""}>
        <Routes>
          <Route
            path="/"
            element={<Navigate to={empId ? "/dashboard" : "/login"} />}
          />
          <Route path="/login" element={<Login />} />
          {empId && (
            <>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/update-timesheet" element={<UpdateTimesheet />} />
              <Route path="/view-timesheet" element={<ViewTimesheet />} />
              <Route path="/lead/*" element={<LeadDashboard />} />
              <Route path="/manager/*" element={<ManagerDashboard />} />
            </>
          )}
          <Route
            path="*"
            element={<Navigate to={empId ? "/dashboard" : "/login"} />}
          />
        </Routes>
      </div>
    </>
  );
};

export default App;
