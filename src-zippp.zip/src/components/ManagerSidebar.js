// ManagerSidebar.js
import React from "react";
import { FaHome, FaListAlt, FaSignOutAlt } from "react-icons/fa";
import "./ManagerSidebar.css";

const ManagerSidebar = ({ setActiveComponent }) => {
  return (
    <div className="manager-sidebar">
      <h2>Manager Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaHome className="icon" /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("view-timesheet")}>
          <FaListAlt className="icon" /> View Timesheet
        </li>
        <li
          onClick={() => {
            localStorage.removeItem("token");
            localStorage.removeItem("empId");
            window.location.href = "/login";
          }}
        >
          <FaSignOutAlt /> Logout
        </li>
      </ul>
    </div>
  );
};

export default ManagerSidebar;
