import React from "react";
import { useAuth } from "../context/AuthContext";
import "./Home.css"; // Make sure to create this file for styling

const Home = () => {
  const { empId } = useAuth();

  return (
    <div className="home-container">
      <div className="home-content">
        <h2>Welcome, Lead</h2>
        <p>Employee ID: {empId}</p>
        <p>We're glad to have you here!</p>
      </div>
    </div>
  );
};

export default Home;
