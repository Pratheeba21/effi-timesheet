// ManagerDashboard.js
import React, { useState } from "react";
import ManagerSidebar from "./ManagerSidebar";
import ManagerHome from "./ManagerHome"; // Updated import
import ManagerPage from "./ManagerPage";
import "./ManagerDashboard.css";

const ManagerDashboard = () => {
  const [activeComponent, setActiveComponent] = useState("home");

  const renderContent = () => {
    switch (activeComponent) {
      case "home":
        return <ManagerHome />;
      case "view-timesheet":
        return <ManagerPage />;
      default:
        return <ManagerHome />;
    }
  };

  return (
    <div className="manager-dashboard">
      <ManagerSidebar setActiveComponent={setActiveComponent} />
      <div className="manager-content">{renderContent()}</div>
    </div>
  );
};

export default ManagerDashboard;
